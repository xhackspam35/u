<?php

$to = 'your-email-goes-here';
  
?>